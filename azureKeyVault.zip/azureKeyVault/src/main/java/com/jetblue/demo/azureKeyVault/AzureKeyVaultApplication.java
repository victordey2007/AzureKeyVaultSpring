package com.jetblue.demo.azureKeyVault;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class AzureKeyVaultApplication implements CommandLineRunner {
	@Value("${apikyeRiproad}")
	private String connectionString;
	
	public static void main(String[] args) {
		
		 SpringApplication.run(AzureKeyVaultApplication.class);
	}

	public void run(String... varl) throws Exception {
		 System.out.println("Sample demo project key Vault");
	      System.out.println("API KEY"+connectionString);
	   }
}

